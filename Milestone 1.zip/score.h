#ifndef SCORE_H
#define SCORE_H
#include <QGraphicsPixmapItem>

class score: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
private:
    int rows, columns;
public:
    score(int row, int column);
};

#endif // SCORE_H
