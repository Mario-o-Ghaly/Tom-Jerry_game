#ifndef CHEESE_H
#define CHEESE_H

#include <QGraphicsPathItem>
#include "home.h"

class Cheese: public QGraphicsPixmapItem
{
    int rows, columns;
    bool atHome;
public:
    Cheese(int row, int column);

    bool IsAtHome();

    void makeAtHome();

public slots:
};

#endif // CHEESE_H
