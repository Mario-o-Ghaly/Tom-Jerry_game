#ifndef POWER_H
#define POWER_H
#include <QGraphicsPathItem>

class power : public QObject , public QGraphicsPixmapItem
{
public:
    power(int row, int column);
};

#endif // POWER_H
