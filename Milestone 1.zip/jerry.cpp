#include "jerry.h"

jerry::jerry(int mazeData[15][15], int Size){
    setImage("jerrys");
    rows = 7, columns = 7;
    setPos(50 + 50*7,50 + 50*7);

    for(int i=0; i<Size; i++){
        for(int j=0; j<Size; j++)
            board[i][j] = mazeData[i][j];
    }

    direction = true;
    heldCheese = NULL;
    powered = false;
    cheeseWin = 0;

}

void jerry::keyPressEvent(QKeyEvent * event){
    if(event->key() == Key_Up && board[rows-1][columns] >= 0)
        rows--;

    else if(event->key() == Key_Down && board[rows+1][columns] >= 0)
        rows++;

    else if(event->key() == Key_Left && board[rows][columns-1] >= 0){
        columns--;
        mirroring();
        direction = false;
    }

    else if(event->key() == Key_Right && board[rows][columns+1] >= 0){
        columns++;
        setPixmap(QPixmap::fromImage(image));  //return the setPixmap to image instead of mirror_image
        direction = true;
    }

    setPos(50 + 50 * columns,50 + 50 * rows);

    QList<QGraphicsItem*> items = collidingItems();
       for (int i = 0; i < items.size(); i++)
       {
           if (typeid(*items[i]) == typeid(Cheese)){
               if(heldCheese == NULL){                             //jerry is not holding a cheese
                   heldCheese = dynamic_cast<Cheese*>(items[i]);   //heldCheese pointer is now pointing at cheese

                   if(heldCheese->IsAtHome() == false){            //if this cheese is at corner not at home then change the picture
                       scene()->removeItem(items[i]);
                       if(Ispowered())
                           setImage("jerry_c_p3");
                       else
                           setImage("jerry_c");

                   }
                   else
                       heldCheese = NULL;
               }
           }

           if(typeid(*items[i]) == typeid(home)){
               home* h = dynamic_cast<home*>(items[i]);
               if(heldCheese != nullptr && !h->exist()){   //jerry is holding a cheese, and there is no cheese at this home slot
                   heldCheese->setPos(50 + h->getColumn() * 50,50 + h->getRow() * 50);
                   scene()->addItem(heldCheese);
                   heldCheese->makeAtHome();
                   h->makeExist();
                   heldCheese = NULL;
                   if(Ispowered())
                       setImage("jerry_p3");
                   else
                       setImage("jerrys");

                   cheeseWin++;
               }

               if(cheeseWin ==4){
                   QMessageBox *msgBox = new QMessageBox;
                   msgBox->setText("You won! \n");
                   msgBox->exec();
                   scene()->clear();
               }
           }

           if (typeid(*items[i]) == typeid(power)){
           {
               powered = true;
               if (heldCheese == nullptr) // not holding cheese
               {
                   scene()->removeItem(items[i]);
                   setImage("jerry_p3");
               }
               else //holding cheese
               {
                   scene()->removeItem(items[i]);
                   setImage("jerry_c_p3");
               }

               //delay
               QTimer::singleShot(5000, this, SLOT(delay()));

           }
       }
           if (typeid(*items[i]) == typeid(portal)){
               if(items[i]->x() == 50){
                   setX(50*14);
                   setPosition(5, 13);
               }
               else{
                   setX(50*2);
                   setPosition(5, 1);
               }
           }

}
}

void jerry::setImage(QString name){       //make it a global function for all classes
    QImage image1(name);                  //It is like a temp image1 to insert tweety in image
    image1 = image1.scaledToWidth(50);    //set size
    image1 = image1.scaledToHeight(50);
    image.swap(image1);                   //insert image1 in image
    setPixmap(QPixmap::fromImage(image)); //this prototype is for converting QImage into QPixmap
    if(!direction)
        mirroring();
}

void jerry::mirroring(){
    QImage mirror;                         //create anothe QImage of tweety and flip it
    mirror = image.scaledToWidth(50);      //set its size equal to image size
    mirror = image.scaledToHeight(50);
    mirror = image.mirrored(true,false);   //mirror
    setPixmap(QPixmap::fromImage(mirror)); //setPixmap now the mirrored image
}

bool jerry::holdingCheese(){
    if (heldCheese == nullptr)
        return false;
    else
        return true;
}

void jerry :: nullify_ptr(){
    scene()->addItem(heldCheese);
    heldCheese = nullptr;
    setImage("jerrys");
}

void jerry::setPosition(int row, int column){
    rows = row; columns = column;
}

bool jerry::Ispowered()
{
    return powered;
}

void jerry::delay(){
    if(heldCheese != NULL){
        setImage("jerry_c");
    }
    else
        setImage("jerrys");

    powered = false;
}
