#include "tom.h"
#include <QMessageBox>

tom::tom(int mazeData[15][15], int Size, score *arr[3]){
    QImage image1("tom");               //It is like a temp image1 to insert tweety in image
    image1 = image1.scaledToWidth(50);    //set size
    image1 = image1.scaledToHeight(50);
    image.swap(image1);                   //insert image1 in image
    setPixmap(QPixmap::fromImage(image)); //this prototype is for converting QImage into QPixmap

    rows = 13, columns = 7;
    setPos(50 + 50*7,50 + 50*13);

    for(int i=0; i<Size; i++){
        for(int j=0; j<Size; j++)
            board[i][j] = mazeData[i][j];
    }
    lives = 3;
    a[0] = arr[0];
    a[1] = arr[1];
    a[2] = arr[2];

    tomScream = new QMediaPlayer();
    tomScream->setMedia(QUrl("qrc:/scream.mp3"));

    isMediaSet = false;

    timer = new QTimer(this);
    QTimer::singleShot(5000, this, SLOT(Tommovement()));
    connect (timer, SIGNAL(timeout()),this, SLOT(Tommovement()));
    timer->start(100);

}

void tom::Tommovement()
{
    srand(time(NULL));
    int random = rand() % 4;
    switch (random) {
    case(0):
    boundaries(rows-1, columns);
    break;
    case(1):
    boundaries(rows+1, columns);
    break;
    case(2):
    boundaries(rows, columns+1);
    mirroring();
    break;
    case(3):
    boundaries(rows, columns-1);
    setPixmap(QPixmap::fromImage(image));
    break;
    }

    QList<QGraphicsItem*> items = collidingItems();
       for (int i = 0; i < items.size(); i++){
           if(typeid(*items[i]) == typeid(jerry)  )
           {

               //cheese back at corner
               jerry *j = dynamic_cast<jerry*>(items[i]);
               if (j->Ispowered() == false)
               {
                   if(j->holdingCheese())
                       j->nullify_ptr();

                   //jerry back at Home
                    j->setPos(50+ 50*7 , 50 + 50*7);
                    j->setPosition(7,7);

                   //tom back at place
                    setPos(50 + 50*7,50 + 50*13);
                    rows = 13; columns = 7;
                    scene()->removeItem(a[--lives]);

                    QMediaPlayer *trial = new QMediaPlayer();
                    trial->setMedia(QUrl("qrc:/scream.mp3"));
                    trial->play();

//                    qDebug()<<tomScream->state();
//                    tomScream->setPosition(0);
//                    tomScream->play();

           }
               if (lives == 0){
                   QMessageBox *msgBox = new QMessageBox;
                   msgBox->setText("You lost! \n");
                   msgBox->exec();
                   scene()->clear();
               }
           }
       }
}

void tom::boundaries(int row, int column){
if(board[row][column] == 0){
    setPos(50 + 50*column, 50 + 50*row);
    rows=row; columns=column;
}
}

void tom::quit(){
    scene()->clear();
}

void tom::mirroring(){
    QImage mirror;                         //create anothe QImage of tweety and flip it
    mirror = image.scaledToWidth(50);      //set its size equal to image size
    mirror = image.scaledToHeight(50);
    mirror = image.mirrored(true,false);   //mirror
    setPixmap(QPixmap::fromImage(mirror)); //setPixmap now the mirrored image
}


