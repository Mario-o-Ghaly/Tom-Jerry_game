#ifndef TOM_H
#define TOM_H
#include <QGraphicsPixmapItem>
#include <QImage>
#include <QList>
#include <time.h>
#include <cstdlib>
#include <QTimer>
#include <QtCore>
#include <QMediaPlayer>
#include "jerry.h"
#include "cheese.h"
#include "score.h"

class tom: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
private:
    int board[15][15];
    int rows, columns;
    QImage image;

    QTimer *timer;
    int lives;
    QMediaPlayer *tomScream;
    bool isMediaSet;
    score *a[3];

public:
    tom(int mazeData[15][15], int Size, score *arr[3]);

    void boundaries(int row, int column);

    void mirroring();

public slots:
    void Tommovement();

    void quit();
};

#endif // TOM_H
