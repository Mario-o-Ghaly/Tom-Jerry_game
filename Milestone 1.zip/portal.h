#ifndef PORTAL_H
#define PORTAL_H
#include <QGraphicsPixmapItem>

class portal: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
private:
    int rows, columns;
    QImage image;
public:
    portal(int row, int column);
};

#endif // PORTAL_H
