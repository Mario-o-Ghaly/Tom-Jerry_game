#include "cheese.h"

Cheese::Cheese(int row, int column): rows(row), columns(column)
{
    QPixmap cheese("cheese");
    cheese = cheese.scaledToHeight(50);
    cheese = cheese.scaledToWidth(50);
    setPixmap(cheese);

    setPos(50 + column*50, 50 + row*50);

    atHome = false;
}

bool Cheese::IsAtHome(){
    return atHome;
}

void Cheese::makeAtHome(){
    atHome = true;
}
