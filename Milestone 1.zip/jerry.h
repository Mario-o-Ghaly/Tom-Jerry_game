#ifndef JERRY_H
#define JERRY_H

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QList>
#include <QImage>
#include <QTimer>
#include <QMediaPlayer>
#include <QMessageBox>
#include "cheese.h"
#include "power.h"
#include "portal.h"

using namespace Qt;

class jerry: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
private:
    int board[15][15];
    int rows, columns;
    QImage image;            //Declaration of image here to use it in case of movement
    bool direction;          //true is for right, and false is for left
    Cheese* heldCheese;
    bool powered;
    int cheeseWin;

public:
    jerry(int mazeData[15][15], int Size);

    void setImage(QString name);

    void mirroring();

    bool holdingCheese();

    void nullify_ptr();

    void setPosition(int row, int column);

    bool Ispowered();

public slots:
    void keyPressEvent(QKeyEvent *event);

    void delay();
};
#endif // JERRY_H
