#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QFile>
#include <QTextStream>

#include <QtCore/QCoreApplication>
#include <stack>
#include "jerry.h"
#include "cheese.h"
#include "tom.h"
#include "home.h"
#include "power.h"
#include "portal.h"
#include "score.h"

using namespace Qt;
void removeHeart(score* arr[3], int i, QGraphicsScene *scene){
    scene->removeItem(&(*arr[i]));
}

int main(int argc, char *argv[]){
    QMediaPlayer *music = new QMediaPlayer();
    music->setMedia(QUrl("qrc:/sounds/bgmusic.mp3"));
    music->setVolume(50);
    music->play();

    QApplication mario(argc,argv);
    QGraphicsScene scene;
    QGraphicsView view;
    view.setFixedSize(900,900); //change the size

    view.setWindowTitle("TJ Maze");

    const int Size = 15;
    int boardData[Size][Size]; //do it with dynamic arrays better

    QFile file("maze.txt");
    file.open(QIODevice::ReadOnly);

    QTextStream stream(&file);
    QString temp;
    for(int i=0;i<Size;i++){
        for(int j=0;j<Size;j++){
            stream>>temp;
            boardData[i][j]=temp.toInt();
        }
    }

    QPixmap bricksImage("bricks");
    QPixmap grassImage("space");


    bricksImage=bricksImage.scaledToWidth(50);
    bricksImage=bricksImage.scaledToHeight(50);


    grassImage=grassImage.scaledToWidth(50);
    grassImage=grassImage.scaledToHeight(50);


//    QBrush bursh(black);
//    view.setBackgroundBrush(bursh);


    QGraphicsPixmapItem boardItems[Size][Size]; //delete the boardData and use this array directly
    for(int i=0;i<Size;i++){
        for(int j=0;j<Size;j++){
            if(boardData[i][j]<0)
                boardItems[i][j].setPixmap(bricksImage);
            else boardItems[i][j].setPixmap(grassImage);
            boardItems[i][j].setPos(50 + j*50, 50 + i*50);
            scene.addItem(&boardItems[i][j]);
        }
    }

    home slot1(6,6);
    home slot2(6,8);
    home slot3(8,6);
    home slot4(8,8);

    scene.addItem(&slot1); //vectors or arrays with the above
    scene.addItem(&slot2);
    scene.addItem(&slot3);
    scene.addItem(&slot4);

    Cheese cheese1(1, 1);  //vectors or arrays
    Cheese cheese2(1, 13);
    Cheese cheese3(13, 1);
    Cheese cheese4(13, 13);

    scene.addItem(&cheese1); //vectors or arrays with the above
    scene.addItem(&cheese2);
    scene.addItem(&cheese3);
    scene.addItem(&cheese4);

    power p1(3,11);
    power p2(8,3);

    scene.addItem(&p1);
    scene.addItem(&p2);


    jerry player(boardData, Size);
    scene.addItem(&player);


    score *arr[3] = { new score(-1,1), new score(-1,2), new score(-1,3) };
    for(int i=0; i<3; i++){
        scene.addItem(&(*arr[i]));
    }

    tom enemy(boardData, Size, arr);
    scene.addItem(&enemy);

    player.setFlag(QGraphicsPixmapItem::ItemIsFocusable);
    player.setFocus();


    portal gate1(5, 0);
    portal gate2(5, 14);

    scene.addItem(&gate1);
    scene.addItem(&gate2);

    view.setScene(&scene);
    view.show();

    return mario.exec();
}



